import asyncio
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ChatMemberHandler,
    ConversationHandler,
    CallbackQueryHandler,
    filters
)

from config.settings import BOT_TOKEN
from config.admin_config import BACKUP_INTERVAL
from database.db import init_database, db
from database.admin_db import get_admin_db
from handlers.main import start_command, welcome_group
from handlers.router import handle_messages
from handlers.mine import (
    start_sell_iron, sell_iron_step,
    start_sell_silver, sell_silver_step,
    SELL_IRON, SELL_SILVER
)
from handlers.admin import admin_panel, admin_callback_handler
from utils.mining_loop import mining_loop
from utils.logger import logger
from utils.log_manager import init_log_manager, get_log_manager
from utils.backup_manager import init_backup_manager, get_backup_manager
from handlers.bank import bank_conversation, bank_menu_handler
# ✅ ایمپورت تابع درست از handlers.war
from handlers.war import attack_text_handler


def main():
    if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        logger.error("❌ Bot token not configured! Please set BOT_TOKEN in .env file.")
        return

    logger.info("Initializing database...")
    init_database()

    logger.info("Building bot application...")
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # 🏦 بخش بانک
    app.add_handler(bank_menu_handler)
    app.add_handler(bank_conversation)

    # ⚙️ Conversation فروش آهن
    conv_handler_iron = ConversationHandler(
        entry_points=[
            MessageHandler(
                filters.TEXT & filters.Regex("🛠️ فروش آهن"),
                start_sell_iron
            )
        ],
        states={
            SELL_IRON: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    sell_iron_step
                )
            ]
        },
        fallbacks=[]
    )

    # ⚙️ Conversation فروش نقره
    conv_handler_silver = ConversationHandler(
        entry_points=[
            MessageHandler(
                filters.TEXT & filters.Regex("⚪ فروش نقره"),
                start_sell_silver
            )
        ],
        states={
            SELL_SILVER: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    sell_silver_step
                )
            ]
        },
        fallbacks=[]
    )

    # 👋 سایر هندلرها پایه
    app.add_handler(ChatMemberHandler(welcome_group, ChatMemberHandler.MY_CHAT_MEMBER))
    app.add_handler(CommandHandler("start", start_command))

    # Conversation handlers
    app.add_handler(conv_handler_iron)
    app.add_handler(conv_handler_silver)

    # -------------------------
    # 🔐 Admin Panel Handlers (باید قبل از MessageHandler عمومی باشه)
    # -------------------------
    
    # ConversationHandler برای اضافه کردن ادمین
    from handlers.admin import (
        start_add_admin, receive_admin_id,
        start_set_log_group, receive_group_id,
        start_search_user, process_search_query,
        start_broadcast, process_broadcast,
        start_broadcast_reward, process_broadcast_reward,
        start_direct_edit, ask_edit_type, ask_edit_amount, process_edit_amount,
        ASK_ADMIN_ID, ASK_GROUP_ID,
        ASK_SEARCH_QUERY, ASK_BROADCAST_MESSAGE, ASK_REWARD_AMOUNT,
        ASK_USER_ID_EDIT, ASK_EDIT_TYPE, ASK_EDIT_AMOUNT
    )
    
    conv_handler_add_admin = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_add_admin, pattern="^admin_add_admin$")
        ],
        states={
            ASK_ADMIN_ID: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    receive_admin_id
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    # ConversationHandler برای تنظیم گروه لاگ
    conv_handler_set_log_group = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_set_log_group, pattern="^admin_set_log_group$")
        ],
        states={
            ASK_GROUP_ID: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    receive_group_id
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    # ConversationHandler برای جستجوی کاربر
    conv_handler_search_user = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_search_user, pattern="^admin_search_user$")
        ],
        states={
            ASK_SEARCH_QUERY: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_search_query
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    # ConversationHandler برای ارسال پیام همگانی
    conv_handler_broadcast = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_broadcast, pattern="^admin_broadcast$")
        ],
        states={
            ASK_BROADCAST_MESSAGE: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_broadcast
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    # ConversationHandler برای پاداش همگانی
    conv_handler_reward = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_broadcast_reward, pattern="^admin_broadcast_reward$")
        ],
        states={
            ASK_REWARD_AMOUNT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_broadcast_reward
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    # ConversationHandler برای ویرایش دارایی
    conv_handler_direct_edit = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_direct_edit, pattern="^admin_direct_edit$")
        ],
        states={
            ASK_USER_ID_EDIT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    ask_edit_type
                )
            ],
            ASK_EDIT_TYPE: [
                CallbackQueryHandler(ask_edit_amount, pattern="^edit_")
            ],
            ASK_EDIT_AMOUNT: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND,
                    process_edit_amount
                )
            ]
        },
        fallbacks=[],
        per_chat=True,
        per_user=True
    )
    
    app.add_handler(conv_handler_add_admin)
    app.add_handler(conv_handler_set_log_group)
    app.add_handler(conv_handler_search_user)
    app.add_handler(conv_handler_broadcast)
    app.add_handler(conv_handler_reward)
    app.add_handler(conv_handler_direct_edit)
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^admin_"))
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^usermng_"))
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^confirm_delete_"))

    # -------------------------
    # 🔰 هندلر حمله (پیش از هندلر عمومی پیام‌ها)
    # شرط: پیام ریپلای شده + متن شروع با "حمله"
    # -------------------------
    app.add_handler(
        MessageHandler(
            (filters.TEXT & filters.Regex(r"^حمله\s+.+$|^حمله$")) & filters.REPLY,
            attack_text_handler
        )
    )
    
    # هندلر ویرایش از جستجوی کاربر (باید قبل از handle_messages باشه)
    from handlers.admin import handle_user_edit_input
    async def check_edit_mode(update, context):
        if 'edit_target_user' in context.user_data and 'edit_type' in context.user_data:
            await handle_user_edit_input(update, context)
            return True
        return False
    
    async def admin_edit_filter(update, context):
        if await check_edit_mode(update, context):
            return
        await handle_messages(update, context)
    
    # هندلر پیام‌های متنی عمومی (باید بعد از همه ConversationHandlerها بیاد)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, admin_edit_filter))

    # -------------------------
    # 🚀 راه‌اندازی سیستم‌های پس‌زمینه
    # -------------------------
    
    # Log Manager - گرفتن LOG_GROUP_ID از دیتابیس
    admin_db = get_admin_db()
    log_group_id = admin_db.get_log_group()
    
    if log_group_id:
        log_manager = init_log_manager(app.bot, log_group_id)
        logger.info(f"Initializing log manager for group: {log_group_id}")
        loop = asyncio.get_event_loop()
        loop.run_until_complete(log_manager.ensure_topics())
        loop.run_until_complete(log_manager.log_system("🟢 بات راه‌اندازی شد"))
    else:
        logger.warning("LOG_GROUP_ID not configured - logging to group disabled")
        logger.info("You can configure it using /admin panel")
    
    # Backup Manager
    backup_manager = init_backup_manager(
        db_path="users.db",
        backup_dir="backups/",
        interval=BACKUP_INTERVAL
    )
    backup_manager.start()
    logger.info("Auto backup started")

    # ⚒️ شروع سیستم ماینینگ
    logger.info("Starting mining loop...")
    loop = asyncio.get_event_loop()
    mining_loop.task = loop.create_task(mining_loop.start())

    # 🚀 شروع بات
    logger.info("Bot is starting (polling mode)...")
    logger.info("Press Ctrl+C to stop the bot.")

    try:
        app.run_polling()
    except KeyboardInterrupt:
        logger.info("Received stop signal. Shutting down...")
        
        # لاگ shutdown
        log_manager = get_log_manager()
        if log_manager:
            loop = asyncio.get_event_loop()
            loop.run_until_complete(log_manager.log_system("🔴 بات متوقف شد"))
    finally:
        mining_loop.stop()
        
        # توقف backup manager
        backup_manager = get_backup_manager()
        if backup_manager:
            backup_manager.stop()
        
        db.close_all()
        logger.info("Bot stopped successfully.")


if __name__ == "__main__":
    main()
